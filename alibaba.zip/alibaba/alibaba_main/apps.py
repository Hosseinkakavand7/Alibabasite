from django.apps import AppConfig


class AlibabaMainConfig(AppConfig):
    name = 'alibaba_main'
